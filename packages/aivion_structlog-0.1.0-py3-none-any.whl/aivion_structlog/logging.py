"""Shared structlog configuration for all AivionLabs services."""

from __future__ import annotations

import logging
import sys
from typing import Any

import structlog
import structlog.contextvars


def configure_logging(
    service: str,
    *,
    json_logs: bool = True,
    level: int = logging.INFO,
    extra_handlers: list[logging.Handler] | None = None,
) -> structlog.stdlib.ProcessorFormatter:
    """
    Configure structlog for the calling service.

    Call once at startup (lifespan). Every log line will include:
      - service   — the service name passed here
      - request_id — bound per-request by RequestIDMiddleware via contextvars
      - level, timestamp, logger name

    Returns the ProcessorFormatter so callers can attach additional handlers
    (e.g. a rotating file handler) that share the same format.
    """

    def _add_service(_logger: Any, _method: str, event_dict: dict) -> dict:
        event_dict.setdefault("service", service)
        return event_dict

    shared_processors: list[Any] = [
        structlog.contextvars.merge_contextvars,  # pulls request_id + path from middleware
        _add_service,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.stdlib.add_logger_name,
        structlog.processors.format_exc_info,
    ]

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    renderer = (
        structlog.processors.JSONRenderer()
        if json_logs
        else structlog.dev.ConsoleRenderer(colors=True)
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared_processors,
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers = [stdout_handler]
    root.setLevel(level)

    if extra_handlers:
        for h in extra_handlers:
            h.setFormatter(formatter)
            root.addHandler(h)

    # Silence noisy third-party loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("google_genai").setLevel(logging.WARNING)
    logging.getLogger("google.auth").setLevel(logging.WARNING)

    return formatter


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Return a structlog bound logger. Use as module-level: log = get_logger(__name__)"""
    return structlog.get_logger(name)
