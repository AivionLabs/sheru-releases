"""FastAPI/Starlette middleware that stamps every request with a UUID."""

from __future__ import annotations

import uuid

import structlog.contextvars
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request


class RequestIDMiddleware(BaseHTTPMiddleware):
    """
    Bind request_id + path to structlog contextvars for the lifetime of each request.

    Reads X-Request-ID from the incoming header so the UUID propagates across
    service hops (Sheru → gateway → …). Generates a fresh UUID if the header
    is absent.

    Redacts ?token= query-string values so short-lived JWTs never appear in logs.
    """

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())

        qs = request.url.query
        if "token=" in qs:
            parts = qs.split("&")
            parts = [("token=***" if p.startswith("token=") else p) for p in parts]
            qs = "&".join(parts)
        logged_path = request.url.path + (f"?{qs}" if qs else "")

        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(
            request_id=request_id,
            path=logged_path,
        )

        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response
