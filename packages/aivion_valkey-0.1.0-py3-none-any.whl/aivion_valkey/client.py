from __future__ import annotations

import redis.asyncio as aioredis

_clients: dict[str, aioredis.Redis] = {}


def get_client(url: str, *, decode_responses: bool = True) -> aioredis.Redis:
    """Return a cached async Redis/Valkey client for the given URL."""
    if url not in _clients:
        _clients[url] = aioredis.from_url(url, decode_responses=decode_responses)
    return _clients[url]


async def close_all() -> None:
    """Close all cached clients. Call from lifespan shutdown."""
    for client in _clients.values():
        await client.aclose()
    _clients.clear()
