"""Built-in health check helpers + HealthChecks registry."""

from __future__ import annotations

import asyncio
import os
from typing import Callable


class HealthChecks:
    """Registry of pluggable async health checks."""

    def __init__(self) -> None:
        self._checks: dict[str, Callable] = {}

    def add(self, name: str, func: Callable) -> None:
        self._checks[name] = func

    async def run(self) -> dict[str, bool]:
        results = {}
        for name, func in self._checks.items():
            try:
                result = await func() if asyncio.iscoroutinefunction(func) else func()
                results[name] = bool(result)
            except Exception:
                results[name] = False
        return results


# ── Built-in check helpers ─────────────────────────────────────────────────────


async def check_postgres(url: str) -> bool:
    """Try opening and closing an asyncpg connection."""
    try:
        import asyncpg
        conn = await asyncpg.connect(url, timeout=3)
        await conn.close()
        return True
    except Exception:
        return False


async def check_valkey(url: str) -> bool:
    """Ping the Valkey/Redis instance."""
    try:
        import redis.asyncio as aioredis
        client = aioredis.from_url(url, socket_connect_timeout=3)
        await client.ping()
        await client.aclose()
        return True
    except Exception:
        return False


async def check_http(url: str) -> bool:
    """GET a URL and expect HTTP 200 — use for gateway reachability (Sheru)."""
    try:
        import httpx
        async with httpx.AsyncClient(timeout=3) as client:
            resp = await client.get(url)
            return resp.status_code == 200
    except Exception:
        return False


def check_env_key(var: str) -> bool:
    """Check an env var is set and non-empty — use for API keys (Gemini)."""
    return bool(os.environ.get(var, "").strip())
