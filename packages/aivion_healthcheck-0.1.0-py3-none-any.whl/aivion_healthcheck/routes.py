"""FastAPI router exposing /livez and /readyz."""

from __future__ import annotations

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from .checks import HealthChecks


def create_health_router(checks: HealthChecks) -> APIRouter:
    """Returns an APIRouter with two endpoints:"""
    router = APIRouter(tags=["health"], include_in_schema=False)

    @router.get("/livez")
    async def livez():
        return JSONResponse({"status": "alive"}, status_code=200)

    @router.get("/readyz")
    async def readyz():
        results = await checks.run()
        all_ok = all(results.values()) if results else True
        status = "ok" if all_ok else "not_ready"
        return JSONResponse(
            {"status": status, "checks": results},
            status_code=200 if all_ok else 503,
        )

    return router
